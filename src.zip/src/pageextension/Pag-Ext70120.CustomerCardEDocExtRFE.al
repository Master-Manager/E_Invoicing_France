pageextension 70120 "Customer Card EDoc Ext RFE" extends "Customer Card"
{
    layout
    {
        addlast(General)
        {
            group("E-Document")
            {
                field("EDoc SIREN"; Rec."EDoc SIREN")
                {
                    ApplicationArea = All;
                }

                field("EDoc SIRET"; Rec."EDoc SIRET")
                {
                    ApplicationArea = All;
                }

                field("EDoc Endpoint ID"; Rec."EDoc Endpoint ID")
                {
                    ApplicationArea = All;
                }
                field("Client Nature"; Rec."Client Nature")
                {
                    ApplicationArea = All;
                }
                field("Assujetti TVA"; Rec."Assujetti TVA")
                {
                    ApplicationArea = All;
                }
            }
        }
    }
}